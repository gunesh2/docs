import React, { useState } from 'react';
import { Story, Meta } from '@storybook/react/types-6-0';
import { AdvancedGrid, IAdvancedGridProps, IColumnConfiguration, AdvancedGridWrapper } from '../../composite';

const columnConfigurationsData: IColumnConfiguration[] = [
  {
    displayname: 'Status',
    columnname: 'status',
    width: '150px',
    filtercolumn: 'status',
    type: 'boolean',
    options: [{ label: 'Active', value: '5' }, { label: 'Inactive', value: '5' }]
  },
  {
    displayname: 'Score',
    columnname: 'score',
    width: '150px',
    filtercolumn: 'score',
    type: 'number',
    options: [{ label: 'ADID', value: '2' }]
  },
  {
    displayname: 'Media',
    columnname: 'media',
    width: '150px',
    filtercolumn: 'media',
    type: 'string',
    options: [{ label: 'media', value: '3' }]
  },
  {
    displayname: 'AdID',
    columnname: 'adid',
    width: '150px',
    filtercolumn: 'adid',
    type: 'string',
    options: [{ label: 'Industry', value: '4' }]
  }
];
const rowDataValues: any[] = [
  { id: 1, score: null, media: 'Online', adid: 'BANKOL-0560', status: false },
  { id: 2, score: null, media: 'Online', adid: 'BANKOL-0561', status: true },
  { id: 3, score: null, media: 'Offline', adid: 'BANKOL-0562', status: true },
  { id: 4, score: null, media: 'Online', adid: 'BANKOL-0563', status: true },
  { id: 5, score: null, media: 'Offline', adid: 'BANKOL-0564', status: true }
];

export default {
  component: AdvancedGrid,
  title: 'Composite/AdvancedGrid'
} as Meta;

const Template: Story<IAdvancedGridProps> = args => <AdvancedGrid {...args} />;

const demoFnctn = () => {
  // comment;
};

const checkClicked = (value: any, row: any, data: any) => {
  // comment;
  console.log("checkClicked Trigger", value, row, data);
};

const defaultArgs: IAdvancedGridProps = {
  columnConfigurations: columnConfigurationsData,
  height: '100%',
  width: '100%',
  rowData: rowDataValues,
  totalCount: 188,
  pageCount: 4,
  id: 'abc',
  onFilterClick: demoFnctn,
  onPageDataChange: demoFnctn,
  onSortDataChange: demoFnctn
};


export const DefaultAdvancedGrid = () => (
  <AdvancedGridWrapper />
);


export const Default = Template.bind({});
Default.args = {
  ...defaultArgs
};

DefaultAdvancedGrid.args = {
  ...defaultArgs
};
