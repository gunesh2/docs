import * as React from 'react';
import {
  Dropdown,
  DropdownPositions,
  Button,
  buttonVariant,
  buttonSize,
  Tooltip,
  tooltipPosition
} from '../../core';
import { FontAwesomeIcon as Icon } from '@fortawesome/react-fontawesome';
import { GridConfiguration } from './DefaultGridConfiguration';
import { faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons';
interface IGridPaginatorProps {
  pageCount: number;
  onPageDataChange: any;
  totalCount: number;
  gridPageData: any;
}

export const PaginatorButton = (props: any) => {
  const { onClick, disabled, title, className = '' } = props;
  return (
    <Tooltip text={title} position={tooltipPosition.right}>
      <Button
        id={title}
        variant={buttonVariant.secondary}
        size={buttonSize.small}
        onClick={onClick}
        disabled={disabled}
        customClass={className}
      >
        {props.children}
      </Button>
    </Tooltip>
  );
};

export const GridPaginator = (props: IGridPaginatorProps) => {
  const { pageCount, onPageDataChange, gridPageData } = props;

  const pageOptions: any = [];
  let i = 1;
  for (i = 1; i <= pageCount; i++) pageOptions.push({ value: i, label: i });

  const onPaginatorButtonClick = (buttonType: string) => {
    let updatedPageNo = 0;
    if (buttonType === 'previous') updatedPageNo = gridPageData.pageNo - 1;
    else if (buttonType === 'next') updatedPageNo = gridPageData.pageNo + 1;

    if (updatedPageNo > 0 && updatedPageNo <= pageCount) onPageNoChange(updatedPageNo);
  };

  const onPageSizeChange = (pageSize: number) => {
    if (pageSize !== gridPageData.pageSize)
      onPageDataChange({
        pageNo: GridConfiguration.Paginator.defaultPage,
        pageSize
      });
  };

  const onPageNoChange = (pageNo: number) => {
    if (pageNo !== gridPageData.pageNo)
      onPageDataChange({
        pageSize: gridPageData.pageSize,
        pageNo
      });
  };

  return (
    <div className='grid-paginator'>
      <div className='grid-paginator-pages'>
        <div className='gridpage'>
          <PaginatorButton
            onClick={() => onPaginatorButtonClick('previous')}
            disabled={gridPageData && gridPageData.pageNo === 1}
            title='Previous'
          >
            <Icon icon={faChevronLeft} />
          </PaginatorButton>
          <Dropdown
            options={pageOptions}
            id='page_no'
            onClick={pageNo => onPageNoChange(pageNo)}
            value={gridPageData && gridPageData.pageNo}
            placement={DropdownPositions.up}
          />
          <PaginatorButton
            onClick={() => onPaginatorButtonClick('next')}
            disabled={gridPageData && gridPageData.pageNo === pageCount}
            title='Next'
            className='next-button'
          >
            <Icon icon={faChevronRight} />
          </PaginatorButton>
        </div>
      </div>
      <div className='grid-paginator-page-size'>
        <div className='grid-paginator-page-size-label'>Page Size</div>
        <Dropdown
          options={GridConfiguration.Paginator.pageSizeVariants}
          id='page_size'
          onClick={pageSize => onPageSizeChange(pageSize)}
          value={gridPageData && gridPageData.pageSize}
          placement={DropdownPositions.up}
        />
      </div>
    </div>
  );
};
