import * as React from 'react';
import { GridPaginator } from './GridPaginator';

export interface IGridFooterProps {
  totalCount: number;
  pageCount: number;
  onPageDataChange: any;
  gridPageData: any;
  isColumnResizeInProgress: boolean;
}

export class GridFooter extends React.Component<IGridFooterProps> {
  shouldComponentUpdate(nextProps: IGridFooterProps): boolean {
    if (nextProps.isColumnResizeInProgress) return false;
    return true;
  }
  render(): JSX.Element {
    const { totalCount, pageCount, onPageDataChange, gridPageData } = this.props;
    return (
      <div className='grid-footer'>
        <GridPaginator
          gridPageData={gridPageData}
          pageCount={pageCount}
          onPageDataChange={onPageDataChange}
          totalCount={totalCount}
        />
        <div className='total-count'>Total Count: {totalCount}</div>
      </div>
    );
  }
}
