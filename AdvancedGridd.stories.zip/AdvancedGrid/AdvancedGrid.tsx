import * as React from 'react';
import { GridHeader } from './GridHeader';
import { GridBody } from './GridBody';
import { IColumnConfiguration } from './ColumnConfiguration';
import { GridFooter } from './GridFooter';
import { useState, useEffect } from 'react';
import { usePrevious, isEqual } from '../../utility';
import './advancedGrid.scss';
import { GridConfiguration } from './DefaultGridConfiguration';
import { LocalStorageManager } from '../../../Framework';
export interface IFilterColumnDisplay {
  filterColumn: string;
  showFilter: boolean;
}

export interface ICustomRowProps {
  value: string | number;
  key: string;
}

export interface IAdvancedGridProps {
  id: string;
  height: string;
  width: string;
  customClass?: string;
  columnConfigurations: IColumnConfiguration[];
  rowData: any[];
  totalCount: number;
  pageCount: number;
  filterColumnConfig?: any;
  onPageDataChange: (type: string, value: any) => void;
  onDoubleClick?: (row: any) => void;
  onClick?: (adID: number) => void;
  onSortDataChange?: (sortConfig: any) => void;
  onFilterClick?: (filterColumn: string) => void;
  onRightClick?: (event: any, row: any) => void;
  onCellClick?: (row: any) => void;
  historyData?: any;
  isFilterAvailable?: boolean;
  isSortPageFilterAvailable?: boolean;
  isFooterAvailable?: boolean;
  sortConfigData?: any;
  gridPageData?: any;
  allowMultiRowSelection?: boolean;
  resetRowSelection?: boolean;
  disableColumnResizing?: boolean;
  uniqueKey?: string;
  showCellPopover?: boolean;
  queryPath?: string;
  disableKey?: string;
  // Below props are for the checkbox
  showCheckbox?: boolean;
  excludedCheckbox?: any[];
  selectedCheckbox?: any[];
  selectAllCheckbox?: boolean;
  onCheckboxClick?: (id: number, value: boolean) => void;
  onRowEditCheckBox?: (obj: any, index: any, data: any) => void;
  isEditable?: any;
  isActions?: any,
  UpdateSelectedItem?: (id: number, status: boolean) => void;
  updateData?: any;
  clickableLinks?: any[];
  customRowProps?: ICustomRowProps;
}

export enum sortOrder {
  asc = 'asc',
  desc = 'desc'
}
export interface IDefaultSortConfig {
  sortColumn: string;
  sortOrderBy: sortOrder.asc | sortOrder.desc;
}
export const AdvancedGrid = ({
  id,
  height,
  width,
  totalCount,
  pageCount,
  columnConfigurations,
  onSortDataChange,
  onPageDataChange,
  rowData,
  onDoubleClick,
  onClick,
  onFilterClick,
  onRightClick,
  onCellClick,
  historyData,
  customClass,
  isFilterAvailable = true,
  isSortPageFilterAvailable = true,
  isFooterAvailable = true,
  filterColumnConfig,
  sortConfigData,
  gridPageData,
  allowMultiRowSelection,
  resetRowSelection,
  disableColumnResizing,
  uniqueKey,
  showCellPopover,
  queryPath,
  disableKey,
  showCheckbox,
  excludedCheckbox,
  selectedCheckbox,
  onCheckboxClick,
  onRowEditCheckBox,
  isEditable,
  isActions,
  UpdateSelectedItem,
  updateData,
  selectAllCheckbox,
  customRowProps
}: IAdvancedGridProps) => {
  const [filterConfig, _setFilterConfig]: any = useState([]);
  const [sortConfig, setSortConfig]: any = useState({
    sortColumn: '',
    sortOrderBy: sortOrder.asc
  });
  const [colWidths, _setColWidths] = useState<any>({});
  const [resizeLineXPos, setResizeLineXPos] = useState<number>(0);
  const [isResizeLineXVisible, setResizeLineXVisible] = useState<boolean>(false);
  const previousSortConfig = usePrevious(sortConfig);
  const colWidthsRef = React.useRef({});
  const filterConfigRef = React.useRef<any>([]);
  const gridRef = React.useRef<any>(null);
  const setColWidths = (widths: any) => {
    _setColWidths(widths);
    colWidthsRef.current = widths;
  };
  const setFilterConfig = (filters: any[]) => {
    filterConfigRef.current = filters;
    _setFilterConfig(filters);
  };
  const userLevelGridColumnWidths: any = uniqueKey
    ? LocalStorageManager.getGridWidthConfig(uniqueKey)
    : {};

  useEffect(() => {
    document.addEventListener('mousedown', outSideClick);
    return () => {
      document.removeEventListener('mousedown', outSideClick);
      if (uniqueKey) LocalStorageManager.setGridWidthConfig(uniqueKey, {});
    };
  }, []);

  useEffect(() => {
    const widthsObj: any = {};
    (columnConfigurations || []).forEach((column: IColumnConfiguration) => {
      widthsObj[column.filtercolumn] =
        (userLevelGridColumnWidths && userLevelGridColumnWidths[column.filtercolumn]) ||
        column.width;
    });
    setColWidths(widthsObj);
  }, [columnConfigurations]);

  useEffect(() => {
    const handleGridColumnResize = (widthObj: any) => {
      if (uniqueKey) LocalStorageManager.setGridWidthConfig(uniqueKey, widthObj);
    };

    if (!disableColumnResizing && colWidths && Object.keys(colWidths).length)
      handleGridColumnResize(colWidths);
  }, [colWidths]);

  useEffect(() => {
    if (previousSortConfig && !isEqual(previousSortConfig, sortConfig) && onSortDataChange)
      onSortDataChange(sortConfig);
  }, [sortConfig]);

  useEffect(() => {
    if (sortConfigData) setSortConfig(sortConfigData);
  }, [sortConfigData]);

  useEffect(() => {
    if (filterColumnConfig) {
      setDefaultFilters();
    }
  }, [filterColumnConfig]);

  useEffect(() => {
    setFilterConfig(
      columnConfigurations.map((columnConfig: any) => ({
        columnName: columnConfig.filtercolumn,
        filterValue: isFilterValueSet(columnConfig.filtercolumn),
        filterDisplay: {
          showFilter: false,
          isFiltered: !!isFilterValueSet(columnConfig.filtercolumn)
        }
      }))
    );
  }, [JSON.stringify(columnConfigurations)]);

  const getNextSortOrder = (nextColumn: string) => {
    const { sortColumn, sortOrderBy } = sortConfig;
    return sortColumn === nextColumn && sortOrderBy === sortOrder.asc
      ? sortOrder.desc
      : sortOrder.asc;
  };

  const onColumnSortClick = (sortColumn: string) => {
    setSortConfig({
      sortColumn,
      sortOrderBy: getNextSortOrder(sortColumn)
    });
  };

  const setShowFilterPopOver = (columnFilterConfig: any, showFilter: boolean) => {
    return {
      ...columnFilterConfig,
      filterDisplay: {
        ...columnFilterConfig.filterDisplay,
        showFilter
      }
    };
  };

  const onFilterIconClick = (filterColumn: string) => {
    setFilterConfig(
      filterConfig.map((columnConfig: any) => {
        if (columnConfig.columnName === filterColumn)
          return setShowFilterPopOver(columnConfig, !columnConfig.filterDisplay.showFilter);
        else return setShowFilterPopOver(columnConfig, false);
      })
    );
  };

  const onFilterClear = (columnName: string) => {
    const allFilters = filterConfig
      .map((columnFilterConfig: any) => {
        if (columnFilterConfig.columnName === columnName) {
          return {
            ...columnFilterConfig,
            filterValue: null
          };
        } else return columnFilterConfig;
      })
      .filter((columnFilterConfig: any) => columnFilterConfig.filterValue)
      .map((columnFilterConfig: any) => columnFilterConfig.filterValue);

    const previousFilters = filterConfig
      .filter((columnFilterConfig: any) => columnFilterConfig.filterValue)
      .map((columnFilterConfig: any) => columnFilterConfig.filterValue);
    if (JSON.stringify(previousFilters) !== JSON.stringify(allFilters) && onFilterClick)
      onFilterClick(allFilters);
  };

  const applyFilters = (filterValue: any) => {
    const allFilters = filterConfig
      .map((columnFilterConfig: any) => {
        if (filterValue && columnFilterConfig.columnName === filterValue.column_name) {
          return {
            ...columnFilterConfig,
            filterValue
          };
        } else return columnFilterConfig;
      })
      .filter((columnFilterConfig: any) => columnFilterConfig.filterValue)
      .map((columnFilterConfig: any) => columnFilterConfig.filterValue);

    const previousFilters = filterConfig
      .filter((columnFilterConfig: any) => columnFilterConfig.filterValue)
      .map((columnFilterConfig: any) => columnFilterConfig.filterValue);
    if (JSON.stringify(previousFilters) !== JSON.stringify(allFilters) && onFilterClick)
      onFilterClick(allFilters);
  };

  const getWidth = () => {
    let widthcount = 0;
    if (colWidths && Object.keys(colWidths).length) {
      Object.keys(colWidths).forEach((column: any) => {
        const itemWidth = colWidths[column]
          ? parseInt(String(colWidths[column]).replace('px', ''), 10)
          : parseInt(String(GridConfiguration.defaultGridCellWidth).replace('px', ''), 10);
        widthcount = widthcount + itemWidth;
      });
    } else if (columnConfigurations) {
      (columnConfigurations || []).forEach((column: any) => {
        const itemWidth = column.width
          ? parseInt(String(column.width).replace('px', ''), 10)
          : parseInt(String(GridConfiguration.defaultGridCellWidth).replace('px', ''), 10);
        widthcount = widthcount + itemWidth;
      });
    }
    // return widthcount < window.screen.width ? '' : widthcount.toString() + 'px';
    return widthcount.toString() + 'px';
  };

  const outSideClick = (event: any) => {
    const visibleFilter = filterConfigRef.current.find(
      (columnFilterConfig: any) =>
        columnFilterConfig &&
        columnFilterConfig.filterDisplay &&
        columnFilterConfig.filterDisplay.showFilter
    );
    if (!visibleFilter) return;
    const popOver = document.getElementById(visibleFilter.columnName) as HTMLElement;

    const datePickers = document.getElementsByClassName('flatpickr-calendar') as HTMLCollection;
    if (popOver.contains(event.target)) return;

    let elementInDatePicker = false;
    Array.from(datePickers).forEach(datePicker => {
      if (datePicker.contains(event.target)) elementInDatePicker = true;
    });
    if (elementInDatePicker) return;
    setFilterConfig(
      filterConfigRef.current.map((columnConfig: any) => {
        return setShowFilterPopOver(columnConfig, false);
      })
    );
  };

  const getClearedFilter = (columnFilterConfig: any) => ({
    ...columnFilterConfig,
    filterValue: null,
    filterDisplay: {
      ...columnFilterConfig.filterDisplay,
      showFilter: false,
      isFiltered: false
    }
  });

  const getNewlyAppliedFilter = (columnFilterConfig: any, newFilterConfig: any) => ({
    ...columnFilterConfig,
    filterValue: newFilterConfig,
    filterDisplay: {
      ...columnFilterConfig.filterDisplay,
      isFiltered: true
    }
  });

  const setDefaultFilters = () => {
    const updatedFilterConfig = filterConfig.map((columnFilterConfig: any) => {
      const newFilterConfig = filterColumnConfig.find(
        (newConfig: any) => newConfig.column_name === columnFilterConfig.columnName
      );
      if (newFilterConfig) return getNewlyAppliedFilter(columnFilterConfig, newFilterConfig);
      else if (!newFilterConfig && columnFilterConfig.filterValue)
        return getClearedFilter(columnFilterConfig);
      else return columnFilterConfig;
    });
    setFilterConfig(updatedFilterConfig);
  };

  const isFilterValueSet = (filterColumnName: string) => {
    return (
      filterColumnConfig &&
      filterColumnConfig.find(
        (columnFilterConfig: any) => columnFilterConfig.column_name === filterColumnName
      )
    );
  };

  const handleColumnResize = (column: string | null, newWidth: string | null) => {
    if (column !== null && newWidth !== null) {
      setColWidths({
        ...colWidthsRef.current,
        [column]: newWidth
      });
    }
  };

  const handleResizeLineXPosChange = (isLineVisible: boolean, newPosition: number) => {
    const gridLeftOfset = gridRef.current.getBoundingClientRect().x;
    const gridWidth = gridRef.current.getBoundingClientRect().width;
    const updatedPos = newPosition - gridLeftOfset;
    if (updatedPos < 0) {
      setResizeLineXPos(0);
    } else if (updatedPos > gridWidth - 5) {
      setResizeLineXPos(gridWidth - 5);
    } else {
      setResizeLineXPos(isLineVisible ? updatedPos : 0);
    }
    setResizeLineXVisible(isLineVisible);
  };

  let columnConfigurationUpdated: any = null;
  if (columnConfigurations) {
    columnConfigurationUpdated = [...columnConfigurations];
    if (showCheckbox) {
      columnConfigurationUpdated = [
        {
          width: '50px',
          displayname: '',
          columnname: '',
          filtercolumn: '',
          options: [],
          type: 'string',
          isCheckboxCell: true
        },
        ...columnConfigurationUpdated
      ];
    }

    if (isEditable) {
      columnConfigurationUpdated = [
        {
          width: '50px',
          displayname: '',
          columnname: '',
          filtercolumn: '',
          options: [],
          type: 'string',
          isEditCheckboxCell: true
        },
        ...columnConfigurationUpdated
      ];
    }

    if (isActions) {
      columnConfigurationUpdated = [
        ...columnConfigurationUpdated,
        {
          width: '250px',
          displayname: '',
          columnname: '',
          filtercolumn: '',
          options: [],
          type: 'string',
          actions: true
        }
      ];
    }



  }

  return (
    <div className='grid-container' style={{ height, width }}>
      <div className='grid' ref={gridRef}>
        <div className='horizontal-scroll scroller'>
          <GridHeader
            id={id}
            width={getWidth()}
            columnConfigurations={columnConfigurationUpdated}
            columnSortConfig={sortConfig}
            filterConfig={filterConfig}
            onCloumnSortClick={onColumnSortClick}
            onFilterClick={applyFilters}
            onFilterClear={onFilterClear}
            isFilterAvailable={isFilterAvailable}
            isSortAvailable={isSortPageFilterAvailable}
            onColumnFilterClick={onFilterIconClick}
            filterInputInFocus={''}
            onResizeLineXPosChange={handleResizeLineXPosChange}
            onColumnResize={handleColumnResize}
            colWidths={colWidths}
            userLevelGridColumnWidths={userLevelGridColumnWidths}
            isColumnResizeInProgress={isResizeLineXVisible}
            disableColumnResizing={disableColumnResizing || false}
            showCheckbox={showCheckbox}
          />

          <GridBody
            width={getWidth()}
            columnConfigurations={columnConfigurationUpdated}
            rowData={rowData}
            onDoubleClick={onDoubleClick}
            onClick={onClick}
            onRightClick={onRightClick}
            onCellClick={onCellClick}
            historyData={historyData}
            showCellPopover={showCellPopover}
            queryPath={queryPath}
            customClass={customClass}
            allowMultiRowSelection={!!allowMultiRowSelection}
            resetRowSelection={resetRowSelection}
            gridPageData={gridPageData}
            colWidths={colWidths}
            userLevelGridColumnWidths={userLevelGridColumnWidths}
            disableColumnResizing={disableColumnResizing || false}
            gridRef={gridRef}
            disableKey={disableKey}
            // Below props are for enabling checkbox
            showCheckbox={showCheckbox}
            excludedCheckbox={excludedCheckbox}
            selectedCheckbox={selectedCheckbox}
            onCheckboxClick={onCheckboxClick}
            onRowEditCheckBox={onRowEditCheckBox}
            isEditable={isEditable}
            isActions={isActions}
            UpdateSelectedItem={UpdateSelectedItem}
            updateData={updateData}
            selectAllCheckbox={selectAllCheckbox}
            customRowProps={customRowProps}
          />
        </div>
        {isFooterAvailable && (
          <GridFooter
            totalCount={totalCount}
            pageCount={pageCount}
            onPageDataChange={onPageDataChange}
            gridPageData={gridPageData}
            isColumnResizeInProgress={isResizeLineXVisible}
          />
        )}
        <div
          className='column-resize-line'
          style={{
            display: isResizeLineXVisible ? 'block' : 'none',
            left: resizeLineXPos + 'px'
          }}
        />
      </div>
    </div>
  );
};
