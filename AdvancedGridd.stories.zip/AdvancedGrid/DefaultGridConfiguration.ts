export const GridConfiguration = {
  defaultGridCellWidth: '200px',
  Paginator: {
    pageSizeVariants: [
      {
        value: 25,
        label: 25
      },
      {
        value: 50,
        label: 50
      },
      {
        value: 75,
        label: 75
      },
      {
        value: 100,
        label: 100
      }
    ],
    defaultPageSize: 50,
    defaultPage: 1
  }
};
