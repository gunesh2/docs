
import React from 'react';
import { AdvancedGrid, IAdvancedGridProps, IColumnConfiguration } from './index';
import { FontAwesomeIcon as Icon } from '@fortawesome/react-fontawesome';
import { faTrash } from '@fortawesome/free-solid-svg-icons';

const columnConfigurationsData: IColumnConfiguration[] = [
    {
        displayname: 'Status',
        columnname: 'status',
        width: '150px',
        filtercolumn: 'status',
        type: 'boolean',
        options: [{ label: 'Active', value: '5' }, { label: 'Inactive', value: '5' }]
    },
    // {
    //     displayname: 'Score',
    //     columnname: 'score',
    //     width: '150px',
    //     filtercolumn: 'score',
    //     type: 'number',
    //     options: [{ label: 'ADID', value: '2' }]
    // },
    // {
    //     displayname: 'Media',
    //     columnname: 'media',
    //     width: '150px',
    //     filtercolumn: 'media',
    //     type: 'string',
    //     options: [{ label: 'media', value: '3' }]
    // },
    {
        displayname: 'AdID',
        columnname: 'adid',
        width: '150px',
        filtercolumn: 'adid',
        type: 'string',
        options: [{ label: 'Industry', value: '4' }]
    }
];
const rowDataValues: any[] = [
    { id: 1, score: null, media: 'Online', adid: 'BANKOL-0560', status: false },
    { id: 2, score: null, media: 'Online', adid: 'BANKOL-0561', status: true },
    { id: 3, score: null, media: 'Offline', adid: 'BANKOL-0562', status: true },
    { id: 4, score: null, media: 'Online', adid: 'BANKOL-0563', status: true },
    { id: 5, score: null, media: 'Offline', adid: 'BANKOL-0564', status: true }
];

const Actions = () => {
    return (
        <>
            Edit&nbsp; delete
        </>
    )
}


export const AdvancedGridWrapper = () => {
    // const [tableData, setTableData]: any = React.useState(rowDataValues.map((item)=>{
    //     item.isEditable = false
    //     return {...item}
    // }));
    const [tableData, setTableData]: any = React.useState(rowDataValues);
    const [selectedItems, setSelectedItems]: any = React.useState([]);


    const demoFnctn = () => {
        // comment;
    };

    const onResHandler = (obj: any, index: any, data: any) => {
        // comment;
        var tmp = tableData;
        tmp[index] = obj;
        setTableData(tmp);
        console.log('Res:', obj, index, data, tmp);
    };

    const saveData = () => {
        console.log('Send Data to API to update', tableData.filter((item: any) => item.isEditable));
    }

    const cancelSave = () => {
        console.log("Cancel data save ");
    }

    const UpdateSelectedItem = (id: any, status: any) => {
        if (status) {
            setSelectedItems((preState: any) => [...preState, id]);
        } else {
            var tmp = selectedItems;
            if (tmp.length > 0) {
                setSelectedItems(tmp.filter((item: any) => id !== item));
            }
        }
        console.log(tmp, selectedItems, status);
    }


    return (
        <>

            {/* {JSON.stringify(tableData)} */}
            No. of selected row: {selectedItems.length}<br />
            {tableData.filter((item: any) => item.isEditable).length > 0 &&
                <>
                    <button onClick={cancelSave}>Cancel</button>
                    <button onClick={saveData}>Save</button>
                </>
            }
            <div style={{ width: "100%" }}>
                <AdvancedGrid
                    columnConfigurations={columnConfigurationsData}
                    height='100%'
                    width='100%'
                    isEditable={true}
                    isActions={[{
                        icon: ()=><Icon icon={faTrash} />,
                        title: "Delete",
                        onClick: (row: any) => console.log('Delete Record:',row)
                    }]}
                    onRowEditCheckBox={(obj: any, index: any, data: any) => { onResHandler(obj, index, data); }}
                    UpdateSelectedItem={UpdateSelectedItem}
                    rowData={tableData}
                    totalCount={188}
                    pageCount={4}
                    id={'abc'}
                    updateData={(data: any) => { setTableData(data) }}
                    onFilterClick={demoFnctn}
                    onPageDataChange={demoFnctn}
                    onSortDataChange={demoFnctn}
                />

            </div>
        </>
    );
};
