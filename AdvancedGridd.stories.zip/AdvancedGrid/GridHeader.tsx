import * as React from 'react';
import { IColumnConfiguration } from './ColumnConfiguration';
import { GridCell } from './GridCell';
import { IDefaultSortConfig } from './AdvancedGrid';
import { isEmpty } from '../../utility';

export interface IGridHeaderProps {
  id: string;
  width: string;
  columnConfigurations: IColumnConfiguration[];
  columnSortConfig: IDefaultSortConfig;
  filterConfig: any;
  onCloumnSortClick: (sortColumn: string) => void;
  onFilterClick: (filterColumn: string) => void;
  onFilterClear: (filterColumn: string) => void;
  isFilterAvailable?: boolean;
  isSortAvailable?: boolean;
  onColumnFilterClick: any;
  filterInputInFocus: string;
  onResizeLineXPosChange: (isLineVisible: boolean, newPosition: number) => void;
  onColumnResize: (id: string | null, width: string | null) => void;
  colWidths: any;
  userLevelGridColumnWidths: any;
  isColumnResizeInProgress: boolean;
  disableColumnResizing: boolean;
  showCheckbox?: boolean;
}

export class GridHeader extends React.Component<IGridHeaderProps> {
  shouldComponentUpdate(nextProps: IGridHeaderProps): boolean {
    if (this.props.isColumnResizeInProgress && nextProps.isColumnResizeInProgress) return false;
    return true;
  }

  private getColumnFilterConfig = (columnName: string) => {
    const { filterConfig } = this.props;
    return (
      filterConfig && filterConfig.find((configItem: any) => configItem.columnName === columnName)
    );
  };

  render(): JSX.Element {
    const {
      id,
      width,
      columnConfigurations,
      columnSortConfig,
      onCloumnSortClick,
      onFilterClick,
      onFilterClear,
      isFilterAvailable,
      isSortAvailable,
      onColumnFilterClick,
      filterInputInFocus,
      onColumnResize,
      colWidths,
      onResizeLineXPosChange,
      isColumnResizeInProgress,
      userLevelGridColumnWidths,
      disableColumnResizing
    } = this.props;
    const { sortColumn, sortOrderBy } = columnSortConfig;

    return (
      <div
        className={`grid-header ${isColumnResizeInProgress ? 'resizing-col' : ''}`}
        style={{ minWidth: `${parseInt(width, 10) - 5}px` }}
      >
        {!isEmpty(columnConfigurations)
          ? columnConfigurations.map((column: IColumnConfiguration) => {
              const columnFilterConfig = this.getColumnFilterConfig(column.filtercolumn);
              return (
                <GridCell
                  id={id}
                  key={column.columnname}
                  column={column}
                  sortable={sortColumn ? sortColumn === column.filtercolumn : false}
                  sortOrder={sortOrderBy}
                  onClick={onCloumnSortClick}
                  filterConfig={columnFilterConfig && columnFilterConfig.filterValue}
                  show={columnFilterConfig && columnFilterConfig.filterDisplay.showFilter}
                  isFiltered={columnFilterConfig && columnFilterConfig.filterDisplay.isFiltered}
                  onColumnFilterClick={onColumnFilterClick}
                  onFilterClear={onFilterClear}
                  isFilterAvailable={isFilterAvailable}
                  isSortAvailable={isSortAvailable}
                  applyFilters={onFilterClick}
                  filterInputInFocus={filterInputInFocus}
                  onResizeLineXPosChange={onResizeLineXPosChange}
                  onColumnResize={onColumnResize}
                  colWidths={colWidths}
                  userLevelGridColumnWidths={userLevelGridColumnWidths}
                  disableColumnResizing={disableColumnResizing}
                />
              );
            })
          : null}
      </div>
    );
  }
}
