import * as React from 'react';
import { useRef } from 'react';
import { IColumnConfiguration } from './ColumnConfiguration';
import { GridConfiguration } from './DefaultGridConfiguration';
import { isEmpty } from '../../utility';
import { useState, useEffect } from 'react';
import moment from 'moment';
import omit from "lodash/omit";
import isEqual from "lodash/isEqual";
import { Icon, Button, CheckboxInput, ToggleButton } from '../../core';
import { faEye } from '@fortawesome/free-regular-svg-icons';
import { CellPopover } from '..';
import { faLock } from '@fortawesome/free-solid-svg-icons';
import { ICustomRowProps } from './AdvancedGrid';

export interface IGridBodyProps {
  rowData: any[];
  width?: string;
  columnConfigurations: IColumnConfiguration[];
  customClass?: string;
  onDoubleClick?: (row: any) => void;
  onClick?: (adID: number) => void;
  onRightClick?: (event: any, row: any) => void;
  onCellClick?: (row: any) => void;
  historyData?: any;
  allowMultiRowSelection?: boolean;
  resetRowSelection?: boolean;
  gridPageData: any;
  colWidths: any;
  userLevelGridColumnWidths: any;
  disableColumnResizing: boolean;
  gridRef: any;
  showCellPopover?: boolean;
  queryPath?: string;
  disableKey?: string;
  showCheckbox?: boolean;
  excludedCheckbox?: any[];
  selectedCheckbox?: any[];
  selectAllCheckbox?: boolean;
  onCheckboxClick?: (id: number, value: boolean) => void;
  isEditable?: any,
  isActions?: any,
  onRowEditCheckBox?: (obj: any, index: any, data: any) => void;
  UpdateSelectedItem?: (id: any, status: any) => void;
  customRowProps?: ICustomRowProps;
  updateData?: any
}
let rowId: number;
let firstColName: string;
let isIconClick: number = 0;


const ToggleWrapper = ({
  disabled, active, onToggleClick, edit
}: any) => {
  const [status, setStatus] = React.useState(active);
  return (
    <>
      <ToggleButton
        disabled={disabled}
        active={status}
        onToggle={(e: any) => {
          if (edit) {
            var tmp = !status;
            setStatus(tmp);
            onToggleClick(tmp)
          }
        }} />
    </>
  )
}



const TableRow = ({ rowIndex, getClassName, queryPath,
  onCellClick, row, allowMultiRowSelection, onGridRowClick, singleRowSelectFlow, onDoubleClick, onRightClick,
  columnConfigurations, colWidths, disableColumnResizing, userLevelGridColumnWidths, rowData,
  onRowEditCheckBox, customClass, getCheckboxVal, onCheckboxClick, showCellPopover,
  historyData, getQueryPopoverPosition, onPopoverClose,
  disableKey, setShowCellPopover, setInfoPopoverPosition, updateData, updateStatus, UpdateSelectedItem, isActions
}: any) => {
  const [edit, setEdit] = React.useState(false);
  const changeEditMode = (status: any) => {
    setEdit(status);
  }

  const getCellWithIcon = (element: any) => {
    return queryPath?.includes(element);
  };

  const getIconString = (iconValues: any, row: any, column: any) => {
    firstColName = column.columnname;
    return (
      <>
        <Button
          id='info'
          customClass='button-style'
          onClick={(event: any) => {
            isIconClick = 1;
            setInfoPopoverPosition(event.clientY);
            onGridRowClick(event, row.id);
            onInfoClick(row, column.columnname);
          }}
        >
          {getIcon(row, queryPath ? queryPath : '')}
        </Button>
        {'  '}
        {iconValues}
      </>
    );
  };

  const getDateString = (dateValues: any) => {
    let dateString = '';
    if (Array.isArray(dateValues)) {
      dateValues.forEach(element => {
        dateString += moment(element).format('MM-DD-YYYY') + ',';
      });
      dateString = dateString.replace(/,\s*$/, '');
    } else {
      dateString = moment(dateValues).format('MM-DD-YYYY');
    }
    return dateString;
  };

  const getDateTimeString = (dateValues: any) => {
    let dateString = '';
    if (Array.isArray(dateValues)) {
      dateValues.forEach(element => {
        dateString += moment(element).format('MM-DD-YYYY hh:mm:ss') + ',';
      });
      dateString = dateString.replace(/,\s*$/, '');
    } else {
      dateString = moment(dateValues).format('MM-DD-YYYY hh:mm:ss');
    }
    return dateString;
  };

  const handleChange = (id: any, columnName: any, value: any) => {
    // console.log(id, columnName, value);
    updateData(rowData.map((row: any, j: any) =>
      row.id === id ? { ...row, [columnName]: value } : row
    ),)
  }

  const getCellValue = (columnIndex: number, row: any, column: any) => {
    const paths = ['query-queue', 'classification-queue', 'indexing-queue', 'component-queue'];
    if (row && row.isEditable) {
      //console.log(row, column)
      return (
        <input type="text" name={column.columnname} value={row[column.columnname]} onChange={(e) => handleChange(row.id, column.columnname, e.target.value)} />
      )
    }
    if (columnIndex === 0 && paths.some(getCellWithIcon)) {
      return getIconString(row[column.columnname], row, column);
    } else {
      if (paths.includes('indexing-queue') && column.columnname === 'length') {
        // for showing creative length as 0
        return row[column.columnname];
      } else if (row[column.columnname]) {
        if (column.type === 'date') {
          return getDateString(row[column.columnname]);
        } else if (column.type === 'datetime') {
          return getDateTimeString(row[column.columnname]);
        } else {
          return row[column.columnname];
        }
      } else {
        return '-';
      }
    }
  };

  const onInfoClick = (row: any, column: any) => {
    if (onCellClick && row.id === rowId && column === firstColName) setShowCellPopover(true);
    else setShowCellPopover(false);
  };
  const getIcon = (row: any, path: string) => {
    if (path.includes('query-queue')) {
      return <Icon icon={faEye} className={'confirmation-icons'} />;
    } else {
      if (disableKey && row[disableKey]) {
        return (
          <Icon
            icon={faLock}
            className={'confirmation-icons'}
            title='This ad is locked by Someone'
          />
        );
      }
    }
    return <></>;
  };

  const getCell = (column: any, columnIndex: any, isHyperLink: any) => {
    if (column.actions) {
      return <>{isActions.map((action: any) => {
        return <><span onClick={() => action.onClick(row)}>{action.icon()}</span></>
      })}</>
    } else if (column.isCheckboxCell) {
      <CheckboxInput
        customClass='grid-cell-checkbox'
        checked={getCheckboxVal(row.id)}
        onChange={() =>
          onCheckboxClick &&
          onCheckboxClick(row.id, !getCheckboxVal(row.id))
        }
      />
    } else if (column.isEditCheckboxCell) {
      return (<input
        type='checkbox'
        defaultChecked={false}
        disabled={false}
        onChange={e => {

          var tmp = rowData;
          if (!e.target.checked) {
            if (!isEqual(omit(row, ['isEditable', 'rowUpdated']), omit(rowData[rowIndex], ['']))) {
              // if (!(JSON.stringify(omit(row, ['isEditable', 'rowUpdated'])) === JSON.stringify(omit(rowData[rowIndex], ['isEditable'])))) {
              row['rowUpdated'] = true;
              tmp[rowIndex]['rowUpdated'] = true;
            }
          }
          tmp[rowIndex]['isEditable'] = e.target.checked;
          row['isEditable'] = e.target.checked;
          UpdateSelectedItem(row.id, e.target.checked);
          onRowEditCheckBox(row, rowIndex, rowData);
          changeEditMode(e.target.checked);
        }}
        tabIndex={-1}
        data-test-class={customClass || ''}
      />)
    } else {
      if (column.type === 'boolean') {
        return (
          <ToggleWrapper
            disabled={column.isEditable}
            active={row[column.columnname]}
            edit={edit}
            onToggleClick={(status: any) => {
              if (edit) {
                row[column.columnname] = status
                handleChange(row.id, column.columnname, status)
              }
            }} />
        )
      }
      return (<>
        <span
          title={getCellValue(columnIndex, row, column)}
          className={`grid-cell-text${isHyperLink ? ' grid-cell-hyperlink' : ''} ${row[column.columnname] ? '' : 'center'
            }`}
        >
          {' '}
          {getCellValue(columnIndex, row, column)}
        </span>
      </>)
    }

  }


  return (
    <>
      <div
        id={'grid-row_' + rowIndex}
        className={getClassName(row)}
        key={rowIndex}
        title={row.isEditable}
        onClick={(event: any) => {
          if (queryPath?.includes('query-queue') && onCellClick && isIconClick === 1) {
            onCellClick(row);
          }
          allowMultiRowSelection
            ? onGridRowClick(event, row.id)
            : singleRowSelectFlow(row.id);
          isIconClick = 0;
        }}
        onDoubleClick={(event: any) => {
          if (onDoubleClick) {
            onDoubleClick(row);
            onGridRowClick(event, row.id);
          }
        }}
        onContextMenu={(event: any) => {
          if (onRightClick) {
            onRightClick(event, row);
            onGridRowClick(event, row.id);
          }
        }}
        tabIndex={1}
      >
        {columnConfigurations.map((column: IColumnConfiguration, columnIndex: number) => {
          const isHyperLink = column.hyperlink && row[column.columnname];
          return (
            <div
              className='grid-cell-wrapper'
              style={{
                width:
                  colWidths[column.filtercolumn] ||
                  (!disableColumnResizing &&
                    userLevelGridColumnWidths[column.filtercolumn]) ||
                  column.width ||
                  GridConfiguration.defaultGridCellWidth
              }}
              key={columnIndex}
              onClick={e => {
                if (isHyperLink && column.hyperlinkClick) {
                  e.stopPropagation();
                  column.hyperlinkClick(row);
                }
              }}
            >
              <div className={`grid-cell`}>
                {getCell(column, columnIndex, isHyperLink)}
              </div>
              {showCellPopover &&
                historyData.length > 0 &&
                row.id === rowId &&
                column.columnname === firstColName ? (
                <CellPopover
                  position={getQueryPopoverPosition()}
                  show={showCellPopover}
                  onClose={onPopoverClose}
                  dataContent={historyData}
                />
              ) : null}
            </div>
          );
        })}
      </div>
    </>
  )
}

export const GridBody = (props: IGridBodyProps) => {
  const {
    rowData,
    width,
    columnConfigurations,
    onDoubleClick,
    onClick,
    onRightClick,
    onCellClick,
    customClass = '',
    allowMultiRowSelection = false,
    resetRowSelection = false,
    gridPageData,
    colWidths,
    userLevelGridColumnWidths,
    disableColumnResizing,
    gridRef,
    disableKey,
    onRowEditCheckBox,
    isEditable,
    isActions,
    UpdateSelectedItem,
    updateData,
  } = props;
  const [selectedItems, setSelectedItems]: any = useState([]);
  const [refresh, setRefresh] = useState(false);
  const [showCellPopover, setShowCellPopover] = useState(props.showCellPopover);
  const infoPopoverYRef = useRef<any>(null);
  const gridBodyRef = useRef<any>();

  const setInfoPopoverPosition = (y: number) => {
    infoPopoverYRef.current = y;
  };

  useEffect(() => {
    if (allowMultiRowSelection && onClick) onClick(selectedItems);
  }, [selectedItems]);

  useEffect(() => {
    if (resetRowSelection) setSelectedItems([]);
  }, [resetRowSelection]);

  useEffect(() => {
    if (gridBodyRef && gridBodyRef.current && gridBodyRef.current.scrollTo)
      gridBodyRef.current.scrollTo(0, 0);
  }, [JSON.stringify(gridPageData)]);

  const onGridRowClick = (event: any, row: number) => {
    if (!event.ctrlKey && !event.metaKey) setSelectedItems((selectedItems.length = 0));
    else onClick && onClick(selectedItems);

    if (selectedItems.find((record: any) => record === row)) {
      const index = selectedItems.indexOf(row);
      selectedItems.splice(index, 1);
      setRefresh(!refresh);
    } else setSelectedItems(selectedItems.concat(row));
    rowId = row;
  };

  const singleRowSelectFlow = (row: number) => {
    if (onClick) {
      setSelectedItems((selectedItems.length = 0));
      setSelectedItems(selectedItems.concat(row));
      onClick(row);
    }
  };

  const onPopoverClose = () => {
    setShowCellPopover(false);
  };

  const getQueryPopoverPosition = (): any => {
    if (gridRef && gridRef.current) {
      const gridTopOfset = gridRef.current.getBoundingClientRect().y;
      const gridHeight = gridRef.current.getBoundingClientRect().height;
      const infoPopoverY = infoPopoverYRef.current || 0;
      if (gridTopOfset + gridHeight - infoPopoverY < 180) return 'top';
    }
    return 'bottom';
  };

  const getClassName = (row: any) => {
    let className = 'grid-row';
    if (disableKey && row[disableKey]) {
      return 'grid-row disable-row';
    }
    if (selectedItems.includes(row.id)) {
      className += ' selected';
    }

    if (props.customRowProps) {
      if (row[props.customRowProps.key] === props.customRowProps.value) {
        className += ' custom-row-color';
      }
    }

    if (row.rowUpdated) {
      className += ' updated-row';
    }
    return className;
    // return `grid-row ${selectedItems.includes(row.id) ? 'selected' : ''}`;
  };



  const getCheckboxVal = (id: number) => {
    if (props.selectAllCheckbox) {
      if (!props.excludedCheckbox?.[id]) {
        return true;
      }
      return false;
    }
    if (props.selectedCheckbox?.[id]) {
      return true;
    }
    return false;
  };

  return (
    <div
      className={`grid-body ${customClass} scroller`}
      style={{ minWidth: width }}
      ref={gridBodyRef}
    >
      {!isEmpty(rowData) ? (
        rowData.map((row: any, rowIndex: number) => {
          return (
            <TableRow
              key={`row-${rowIndex}`}
              rowIndex={rowIndex}
              getClassName={getClassName}
              queryPath={props.queryPath}
              onCellClick={onCellClick} row={row}
              allowMultiRowSelection={allowMultiRowSelection}
              onGridRowClick={onGridRowClick}
              singleRowSelectFlow={singleRowSelectFlow}
              onDoubleClick={onDoubleClick}
              onRightClick={onRightClick}
              columnConfigurations={columnConfigurations}
              colWidths={colWidths}
              disableColumnResizing={disableColumnResizing}
              userLevelGridColumnWidths={userLevelGridColumnWidths}
              rowData={rowData}
              onRowEditCheckBox={onRowEditCheckBox}
              customClass={customClass}
              getCheckboxVal={getCheckboxVal}
              onCheckboxClick={props.onCheckboxClick}
              showCellPopover={showCellPopover}
              historyData={props.historyData}
              getQueryPopoverPosition={getQueryPopoverPosition}
              onPopoverClose={onPopoverClose}
              disableKey={disableKey}
              setShowCellPopover={setShowCellPopover}
              setInfoPopoverPosition={setInfoPopoverPosition}
              updateData={updateData}
              UpdateSelectedItem={UpdateSelectedItem}
              isActions={isActions}
            />
          );
        })
      ) : (
        <div className='grid-row no-records-found'> No Records Found </div>
      )}
    </div>
  );
};
