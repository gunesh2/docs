import * as React from 'react';
import { GridConfiguration } from './DefaultGridConfiguration';
import { IColumnConfiguration } from './ColumnConfiguration';
import { FilterPopover } from '../FilterPopover';
import {
  TextInput,
  inputType,
  FormGroup,
  FormItemLabel,
  Dropdown,
  DatePicker,
  ErrorMessage
} from '../../core';
import { FontAwesomeIcon as Icon } from '@fortawesome/react-fontawesome';
import { faArrowUp, faArrowDown } from '@fortawesome/free-solid-svg-icons';
import { useState, useEffect } from 'react';
import moment from 'moment';
import { gridCellFilterMenu } from './GridDropdownConfiguration';
import { NumericInput } from '../../composite';
import { PATTERNS } from '../../utility/Constants';

export interface IGridCellProps {
  id: string;
  column: IColumnConfiguration;
  sortable: boolean;
  sortOrder: string;
  filterConfig: any;
  show: boolean;
  onClick: (sortColumn: string) => void;
  onColumnFilterClick: (filterColumn: string) => void;
  onFilterClear: (filterColumn: string) => void;
  isFilterAvailable?: boolean;
  isSortAvailable?: boolean;
  applyFilters: any;
  isFiltered: boolean;
  filterInputInFocus: any;
  onResizeLineXPosChange: (isLineVisible: boolean, newPosition: number) => void;
  onColumnResize: (id: string | null, width: string | null) => void;
  colWidths: any;
  userLevelGridColumnWidths: any;
  disableColumnResizing: boolean;
}

export const GridCell = ({
  id,
  column,
  sortable,
  onClick,
  sortOrder,
  filterConfig,
  show,
  onColumnFilterClick,
  onFilterClear,
  isFilterAvailable,
  isSortAvailable,
  applyFilters,
  isFiltered,
  onResizeLineXPosChange,
  onColumnResize,
  colWidths,
  userLevelGridColumnWidths,
  disableColumnResizing
}: IGridCellProps) => {
  const [filterValue, setFilterValue]: any = useState(null);
  const [errorMessage, setErrorMessage] = useState('');
  const [isRange, setRange] = useState(false);
  const [selectDate, setSelectDate] = useState<null | Date>(null);
  const [fromDate, setFromDate] = useState<null | Date>(null);
  const [toDate, setToDate] = useState<null | Date>(null);
  const [filterby, setFilterBy] = useState('eq');
  const [selectNumber, setSelectNumber] = useState<number | string>('');
  const [fromNumber, setFromNumber] = useState<number | string>();
  const [toNumber, setToNumber] = useState<number | string>();
  const gripRef: any = React.useRef(null);
  const colWidthsRef = React.useRef(colWidths);
  const setColWidths = (widths: any) => {
    colWidthsRef.current = widths;
  };
  const colWidthsBeforeResizeRef = React.useRef(colWidths);
  const setColWidthsBeforeResize = (widths: any) => {
    colWidthsBeforeResizeRef.current = widths;
  };
  let resizeStartPositionX: number = 0;

  const onStringFilterInputChange = (event: any) => {
    const updatedFilterConfig = {
      ...filterValue,
      column_name: column.filtercolumn,
      contains: event.target.value
    };
    setFilterValue(updatedFilterConfig);
  };

  const getDataFilterConfig = () => {
    const obj = filterConfig;
    if (obj) {
      const values = Object.entries(obj);
      if (values.length === 2) {
        const keyvalue = values[1].toString().split(',');
        const keyname = keyvalue[0];
        setFilterBy(keyname);
        if (column.type === 'date' || column.type === 'datetime') {
          const date = new Date(keyvalue[1]);
          setSelectDate(date);
        } else {
          setSelectNumber(Number(keyvalue[1]));
        }
        setRange(false);
      }
      if (values.length === 3) {
        const fromvalue = values[1].toString().split(',');
        const tovalue = values[2].toString().split(',');
        if (fromvalue[0] === 'gte') {
          if (column.type === 'date' || column.type === 'datetime') {
            const fromdate = new Date(fromvalue[1]);
            setFromDate(fromdate);
          } else setFromNumber(Number(fromvalue[1]));
        }
        if (tovalue[0] === 'lte') {
          if (column.type === 'date' || column.type === 'datetime') {
            const todate = new Date(tovalue[1]);
            setToDate(todate);
          } else setToNumber(Number(tovalue[1]));
        }
        setRange(true);
        setFilterBy('range');
      }
    } else {
      setSelectNumber('');
      setFromNumber('');
      setToNumber('');
      setFromDate(null);
      setToDate(null);
      setSelectDate(null);
    }
  };

  useEffect(() => {
    if (column.type === 'date' || column.type === 'number' || column.type === 'datetime')
      getDataFilterConfig();

    if (gripRef && gripRef.current) {
      gripRef.current.addEventListener('mousedown', onColumnResizingStart);
    }
  }, []);

  useEffect(() => {
    setFilterValue(filterConfig);
    if (column.type === 'date' || column.type === 'number' || column.type === 'datetime')
      getDataFilterConfig();
  }, [JSON.stringify(filterConfig)]);

  useEffect(() => {
    setColWidths(colWidths);
  }, [colWidths]);

  const onColumnResizingStart = (event: any): void => {
    event.preventDefault();
    resizeStartPositionX = event.clientX;
    setColWidthsBeforeResize({
      ...colWidthsBeforeResizeRef.current,
      [column.filtercolumn]: colWidthsRef.current[column.filtercolumn]
    });
    onResizeLineXPosChange(true, resizeStartPositionX);
    document.addEventListener('mousemove', onColumnResizingInProgress);
    document.addEventListener('mouseup', onColumnResizingEnd);
  };

  const onColumnResizingInProgress = (event: any): void => {
    event.preventDefault();
    onResizeLineXPosChange(true, event.clientX);
  };

  const onColumnResizingEnd = (event: any): void => {
    event.preventDefault();
    const offset = event.clientX - resizeStartPositionX;
    const newWidth =
      parseInt(
        String(colWidthsBeforeResizeRef.current[column.filtercolumn]).replace(/\D/g, ''),
        10
      ) + offset;
    setColWidthsBeforeResize({
      ...colWidthsBeforeResizeRef.current,
      [column.filtercolumn]: newWidth
    });
    onColumnResize(column.filtercolumn, (newWidth > 120 ? newWidth : 120) + 'px');
    onResizeLineXPosChange(false, event.clientX);
    document.removeEventListener('mousemove', onColumnResizingInProgress);
    document.removeEventListener('mouseup', onColumnResizingEnd);
  };

  const onNumberFilterInputChange = (event: any) => {
    const filteredNumber = event.target.value.replace(PATTERNS.AllowOnlyNumericInput, ``);
    const getNumber = filteredNumber && Number(filteredNumber);

    setSelectNumber(getNumber);
    const upDatedFilterConfig = {
      column_name: column.filtercolumn,
      [event.target.name]: getNumber
    };
    setFilterValue(upDatedFilterConfig);
  };

  const onFromNumberChange = (event: any) => {
    const filteredFromNumber = event.target.value.replace(PATTERNS.AllowOnlyNumericInput);
    const getFromNumber = filteredFromNumber && Number(filteredFromNumber);
    setFromNumber(getFromNumber);
    const upDatedFilterConfig = {
      ...filterValue,
      column_name: column.filtercolumn,
      [event.target.name]: getFromNumber
    };
    setFilterValue(upDatedFilterConfig);
  };

  const onToNumberChange = (event: any) => {
    const filteredToNumber = event.target.value.replace(PATTERNS.AllowOnlyNumericInput, ``);
    const getToNumber = filteredToNumber && Number(filteredToNumber);
    setToNumber(getToNumber);
    const upDatedFilterConfig = {
      ...filterValue,
      column_name: column.filtercolumn,
      [event.target.name]: getToNumber
    };
    setFilterValue(upDatedFilterConfig);
  };

  const onDateChange = (date: any) => {
    setSelectDate(date);

    const upDatedFilterConfig = {
      column_name: column.filtercolumn,
      [filterby]: moment.utc(date).format()
    };
    setFilterValue(upDatedFilterConfig);
  };

  const onFromDateChange = (date: any) => {
    setFromDate(date);
    const upDatedFilterConfig = {
      ...filterValue,
      column_name: column.filtercolumn,
      gte: moment.utc(date).format()
    };
    setFilterValue(upDatedFilterConfig);
  };

  const onToDateChange = (date: any) => {
    setToDate(date);
    const upDatedFilterConfig = {
      ...filterValue,
      column_name: column.filtercolumn,
      lte: moment.utc(date).format()
    };
    setFilterValue(upDatedFilterConfig);
  };

  const resetDateFilter = () => {
    setRange(false);
    setFilterBy('eq');
    setSelectNumber('');
    setFromNumber('');
    setToNumber('');
    setFromDate(null);
    setSelectDate(null);
    setToDate(null);
    setErrorMessage('');
  };

  const onFilterChange = (filterId: any) => {
    setFilterBy(filterId);
    setFromDate(null);
    setSelectDate(null);
    setToDate(null);
    setSelectNumber('');
    setFromNumber('');
    setToNumber('');

    if (filterId === 'range') {
      setRange(true);
    } else {
      setRange(false);
    }
    setFilterValue({ column_name: column.filtercolumn, [filterId]: '' });
  };

  const validateDateFilters = () => {
    if (isRange && ((!fromDate && toDate) || (fromDate && !toDate))) {
      setErrorMessage('Define From or To Date');
      return false;
    } else return true;
  };

  const isFilterValueValid = (): boolean => {
    let isValueEmpty = false;
    for (const property in filterValue)
      if (property !== 'column_name' && property !== 'range' && filterValue[property] === '') {
        isValueEmpty = true;
      }
    return !isValueEmpty;
  };

  const validateNumberFilters = () => {
    if (isRange && fromNumber && toNumber && fromNumber > toNumber) {
      setErrorMessage('Enter Valid Numbers');
      return false;
    } else if (isRange && ((!fromNumber && toNumber) || (fromNumber && !toNumber))) {
      setErrorMessage('Define From or To Number');
      return false;
    } else return true;
  };

  const onFilter = () => {
    const dateCondition =
      (column.type === 'date' || column.type === 'datetime') &&
      validateDateFilters() &&
      isFilterValueValid();
    const numberCondition =
      column.type === 'number' && validateNumberFilters() && isFilterValueValid();
    const otherCondition =
      column.type !== 'number' && column.type !== 'date' && isFilterValueValid();
    if (dateCondition || numberCondition || otherCondition) filterGrid();
  };

  const filterGrid = () => {
    setErrorMessage('');
    applyFilters(filterValue);
    onColumnFilterClick(column.filtercolumn);
  };

  const getStringColumnTypeFilterPopoverBody = () => {
    if (column.options) {
      return (
        <FormGroup customClass='filter-input-form-group'>
          <FormItemLabel customClass='filter-label'>Status</FormItemLabel>
          <Dropdown
            id={column.displayname}
            value={filterValue ? filterValue.contains : ''}
            options={column.options ? column.options : []}
            onClick={onDropDownOptionClick}
            autofocus={true}
          />
        </FormGroup>
      );
    } else {
      return (
        <FormGroup customClass='filter-input-form-group'>
          <FormItemLabel customClass='filter-label'>Contains</FormItemLabel>
          <TextInput
            id={column.displayname}
            type={inputType.text}
            name={column.filtercolumn}
            value={filterValue && filterValue.contains ? filterValue.contains : ''}
            customClass='filter-input'
            onChange={onStringFilterInputChange}
            autofocus={true}
          />
        </FormGroup>
      );
    }
  };

  const getNumberColumnTypeFilterPopoverBody = () => {
    return (
      <>
        <FormGroup customClass='filter-input-form-group'>
          <FormItemLabel customClass='filter-label'>Filter By</FormItemLabel>
          <Dropdown
            id='number_fltr_drpdwn'
            options={gridCellFilterMenu}
            onClick={onFilterChange}
            value={filterby ? filterby : 'eq'}
            tabIndex={0}
          />
        </FormGroup>

        {isRange ? (
          <>
            <small>{errorMessage ? <ErrorMessage message={errorMessage} /> : null}</small>
            <FormGroup customClass='filter-input-form-group'>
              <FormItemLabel customClass='filter-label'>From Number</FormItemLabel>
              <NumericInput
                id={column.columnname + '_rgte'}
                name='gte'
                value={fromNumber ? fromNumber : ''}
                placeholder=''
                onChange={onFromNumberChange}
                autofocus={filterby === 'range'}
              />
            </FormGroup>

            <FormGroup customClass='filter-input-form-group'>
              <FormItemLabel customClass='filter-label'>To Number</FormItemLabel>
              <NumericInput
                id={column.columnname + '_rlte'}
                name='lte'
                value={toNumber ? toNumber : ''}
                placeholder=''
                onChange={onToNumberChange}
              />
            </FormGroup>
          </>
        ) : (
          <>
            <FormGroup customClass='filter-input-form-group'>
              <FormItemLabel customClass='filter-label'>Enter Number</FormItemLabel>
              <NumericInput
                id={column.columnname + '_' + filterby}
                name={filterby ? filterby : ''}
                value={selectNumber}
                placeholder=''
                key={filterby}
                onChange={onNumberFilterInputChange}
                autofocus={filterby !== 'range'}
              />
            </FormGroup>
          </>
        )}
      </>
    );
  };

  const getDateColumnTypeFilterPopoverBody = () => {
    return (
      <div className='date-column-filter'>
        <div>
          <FormGroup customClass='filter-input-form-group'>
            <FormItemLabel customClass='filter-label'>Filter By</FormItemLabel>
            <Dropdown
              id='grd_fltr_drpdwn'
              options={gridCellFilterMenu}
              onClick={onFilterChange}
              value={filterby ? filterby : 'eq'}
              autofocus={true}
            />
          </FormGroup>
        </div>
        {isRange ? (
          <>
            <small>{errorMessage ? <ErrorMessage message={errorMessage} /> : null}</small>
            <FormGroup customClass='filter-input-form-group'>
              <FormItemLabel customClass='filter-label'>From Date</FormItemLabel>
              <DatePicker
                id={column.columnname + '_rlte'}
                name='rlte'
                date={fromDate}
                onChange={onFromDateChange}
                customClass='filter-input'
                maxDate={toDate ? toDate : null}
                autofocus={true}
                clearDate={() => {
                  setFromDate(null);
                  setFilterValue(null);
                }}
              />
            </FormGroup>

            <FormGroup customClass='filter-input-form-group'>
              <FormItemLabel customClass='filter-label'>To Date</FormItemLabel>
              <DatePicker
                id={column.columnname + '_rgte'}
                name='rgte'
                date={toDate}
                onChange={onToDateChange}
                customClass='filter-input'
                minDate={fromDate ? fromDate : null}
                clearDate={() => {
                  setToDate(null);
                  setFilterValue(null);
                }}
              />
            </FormGroup>
          </>
        ) : (
          <>
            <FormGroup customClass='filter-input-form-group'>
              <FormItemLabel customClass='filter-label'>Select Date</FormItemLabel>
              <DatePicker
                id={column.columnname + '_' + filterby}
                name={filterby ? filterby : ''}
                date={selectDate}
                onChange={onDateChange}
                customClass='filter-input'
                autofocus={true}
                clearDate={() => {
                  setSelectDate(null);
                  setFilterValue(null);
                }}
              />
            </FormGroup>
          </>
        )}
      </div>
    );
  };

  const onDropDownOptionClick = (item: any) => {
    const updatedFilterConfig = {
      ...filterValue,
      column_name: column.filtercolumn,
      contains: item
    };
    setFilterValue(updatedFilterConfig);
  };

  const getFilterPopOverBodyByColumnType = (columnType: any): JSX.Element => {
    switch (columnType) {
      case 'number':
        return getNumberColumnTypeFilterPopoverBody();

      case 'string':
        return getStringColumnTypeFilterPopoverBody();

      case 'date':
      case 'datetime':
        return getDateColumnTypeFilterPopoverBody();

      case 'boolean':
        return (
          <FormGroup customClass='filter-input-form-group'>
            <FormItemLabel customClass='filter-label'>Status</FormItemLabel>
            <Dropdown
              id={column.displayname}
              value={filterValue ? filterValue.contains : ''}
              options={column.options ? column.options : []}
              onClick={onDropDownOptionClick}
              autofocus={true}
            />
          </FormGroup>
        );

      default:
        return <></>;
    }
  };

  return (
    <div
      className='header-grid-cell'
      style={{
        width:
          colWidths[column.filtercolumn] ||
          (!disableColumnResizing && userLevelGridColumnWidths[column.filtercolumn]) ||
          column.width ||
          GridConfiguration.defaultGridCellWidth
      }}
      key={id}
      // onMouseMove={()=> onColumnResize && onColumnResize(columnIndex)}
    >
      <div
        className={`sort-container ${isSortAvailable ? '' : 'sort-disabled-container'}`}
        onClick={event => {
          event.stopPropagation();
          onClick(column.filtercolumn);
        }}
      >
        <div
          className={`header-grid-cell-text ${
            isSortAvailable ? '' : 'header-sort-disabled-cell-text'
          }`}
        >
          {column.displayname}
        </div>
        {sortable && isSortAvailable && (
          <div className='column-sort'>
            {<Icon icon={sortOrder === 'asc' ? faArrowUp : faArrowDown} />}
          </div>
        )}
      </div>
      {column.filtercolumn && (
        <div className='filter-container' onClick={event => event.stopPropagation()}>
          <FilterPopover
            id={column.filtercolumn}
            show={show}
            isFilterAvailable={isFilterAvailable}
            onPopoverClick={() => {
              setFilterValue(filterConfig);
              if (column.type === 'date' || column.type === 'number') getDataFilterConfig();
              onColumnFilterClick(column.filtercolumn);
            }}
            onFilter={onFilter}
            onClear={() => {
              onFilterClear(column.filtercolumn);
              setFilterValue(null);
              resetDateFilter();
            }}
            isFilled={isFiltered}
          >
            {getFilterPopOverBodyByColumnType(column.type)}
          </FilterPopover>
        </div>
      )}
      {!disableColumnResizing ? <div className='col-resize-grip' ref={gripRef} /> : null}
    </div>
  );
};
