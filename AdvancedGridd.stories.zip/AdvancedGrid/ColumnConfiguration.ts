interface IOption {
  label: string;
  value: string;
}
export interface IColumnConfiguration {
  displayname: string;
  columnname: string;
  width: string;
  filtercolumn: string;
  type: 'number' | 'string' | 'date' | 'boolean' | 'datetime';
  options: IOption[];
  isCheckboxCell?: boolean;
  isEditable?:boolean;
  isEditCheckboxCell?:boolean;
  actions?:any;
  hyperlink?: boolean;
  hyperlinkClick?: any;
}
