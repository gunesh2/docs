export const gridCellFilterMenu = [
  { value: 'eq', label: 'Equal To' },
  { value: 'gt', label: 'Greater Than' },
  { value: 'gte', label: 'Greater Than or Equal' },
  { value: 'lt', label: 'Less Than' },
  { value: 'lte', label: 'Less Than or Equal' },
  { value: 'ne', label: 'Not Equal' },
  // { value: 'range', label: 'Range' }
];
